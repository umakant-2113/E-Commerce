writeCode

Extend Assignment level 3 from prevoius chapter to

- implement an admin dashboard to
- view all users
- view all products
- view all categories
- view product based on categories

- add categories to product
- list categories
- user/admin can view product list based on categories

- verify whether `user` or `admin` is logged in
- add logout for both `user` and `admin` seperately.

- logged in admin can view list of all users
- logged in user can block/unblock a user.
